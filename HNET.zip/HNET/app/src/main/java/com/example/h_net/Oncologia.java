package com.example.h_net;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class Oncologia extends AppCompatActivity {

    Button btnInventario, btnSinInventario, btnInicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oncologuia);

        btnInventario = findViewById(R.id.btnInventario);
        btnSinInventario = findViewById(R.id.btnSinInventario);
        btnInicio = findViewById(R.id.btnInicio);

        btnInventario.setOnClickListener(v ->
                Toast.makeText(this, "Mostrando inventario disponible", Toast.LENGTH_SHORT).show()
        );

        btnSinInventario.setOnClickListener(v ->
                Toast.makeText(this, "Mostrando productos sin inventario", Toast.LENGTH_SHORT).show()
        );
        btnInicio.setOnClickListener(v -> {
                    Intent intent = new Intent(Oncologia.this, Inicio.class);
                    startActivity(intent);
                }
        );
    }
}
