package com.example.h_net;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Perfil extends AppCompatActivity {

    ImageView imgPerfil;
    TextView txtNombreHospital, txtCorreo, txtTelefono, txtEncargado, txtEstado, txtMunicipio;
    Button btnCerrarSesion, btnRegresarInicio;

    DB dbHelper;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // ==============================
        // Conectar vistas
        // ==============================
        imgPerfil = findViewById(R.id.imgPerfil);
        txtNombreHospital = findViewById(R.id.txtNombreHospital);
        txtCorreo = findViewById(R.id.txtCorreo);
        txtTelefono = findViewById(R.id.txtTelefono);
        txtEncargado = findViewById(R.id.txtEncargado);
        txtEstado = findViewById(R.id.txtEstado);
        txtMunicipio = findViewById(R.id.txtMunicipio);

        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        btnRegresarInicio = findViewById(R.id.btnRegresarInicio);

        dbHelper = new DB(this);

        // ==============================
        // Obtener correo del usuario logueado
        // ==============================
        sharedPreferences = getSharedPreferences("sesion", MODE_PRIVATE);
        String correo = sharedPreferences.getString("correo", null);

        if (correo != null) {
            mostrarDatosUsuario(correo);
        } else {
            Toast.makeText(this, "No hay usuario logueado", Toast.LENGTH_SHORT).show();
        }

        // ==============================
        // Acción botón Cerrar Sesión
        // ==============================
        btnCerrarSesion.setOnClickListener(v -> {
            sharedPreferences.edit().clear().apply();
            startActivity(new Intent(Perfil.this, LoginActivity.class));
            finish();
        });

        // ==============================
        // Acción botón Regresar a Inicio
        // ==============================
        btnRegresarInicio.setOnClickListener(v -> {
            startActivity(new Intent(Perfil.this, Inicio.class));
            finish();
        });
    }

    // ==============================
    // Método para mostrar datos del usuario
    // ==============================
    private void mostrarDatosUsuario(String correo) {

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT nombreHospital, telefono, correo, encargado, estado, municipio " +
                        "FROM " + DB.TABLE_CLIENTES + " WHERE correo = ?",
                new String[]{correo}
        );

        if (cursor.moveToFirst()) {
            txtNombreHospital.setText(cursor.getString(0));
            txtTelefono.setText(cursor.getString(1));
            txtCorreo.setText(cursor.getString(2));
            txtEncargado.setText(cursor.getString(3));
            txtEstado.setText(cursor.getString(4));
            txtMunicipio.setText(cursor.getString(5));
        } else {
            Toast.makeText(this, "No se encontraron datos del usuario", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
    }
}