package com.example.h_net;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DB extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";

    private static final String DATABASE_NAME = "dataBase.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_CLIENTES = "clientes";
    public static final String TABLE_SOLICITUDES = "solicitudes";
    public static final String TABLE_DONACIONES = "donaciones";

    public DB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String createClientesTable = "CREATE TABLE " + TABLE_CLIENTES + "(" +
                    "nombreHospital TEXT, " +
                    "telefono TEXT, " +
                    "correo TEXT PRIMARY KEY, " +
                    "encargado TEXT, " +
                    "estado TEXT, " +
                    "municipio TEXT, " +
                    "contrasenia TEXT)";
            db.execSQL(createClientesTable);

            String createSolicitudesTable = "CREATE TABLE " + TABLE_SOLICITUDES + "(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombreMedicamento TEXT, " +
                    "cantidad TEXT, " +
                    "descripcion TEXT, " +
                    "correoUsuario TEXT, " +  // <- NUEVO CAMPO
                    "fechaSolicitud TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
            db.execSQL(createSolicitudesTable);

            String createDonacionesTable = "CREATE TABLE " + TABLE_DONACIONES + "(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT, " +
                    "cantidad TEXT, " +
                    "fechaCaducidad TEXT, " +
                    "descripcion TEXT, " +
                    "fechaRegistro TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
            db.execSQL(createDonacionesTable);

        } catch (SQLException e) {
            Log.e(TAG, "Error creando tablas: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLIENTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SOLICITUDES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DONACIONES);
        onCreate(db);
    }

    public String guardar(String nombreHospital, String telefono, String correo,
                          String encargado, String estado, String municipio, String contrasenia) {

        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues contenedor = new ContentValues();
        contenedor.put("nombreHospital", nombreHospital);
        contenedor.put("telefono", telefono);
        contenedor.put("correo", correo);
        contenedor.put("encargado", encargado);
        contenedor.put("estado", estado);
        contenedor.put("municipio", municipio);
        contenedor.put("contrasenia", contrasenia);

        long resultado = database.insert(TABLE_CLIENTES, null, contenedor);

        if (resultado == -1) {
            return "Error al registrar usuario";
        } else {
            return "Registrado correctamente. Contraseña: 12345";
        }
    }

    public boolean verificarLogin(String correo, String contrasenia) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_CLIENTES + " WHERE correo = ? AND contrasenia = ?",
                new String[]{correo, contrasenia}
        );

        boolean existe = cursor.getCount() > 0;

        cursor.close();
        return existe;
    }

    public boolean existeCorreo(String correo) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_CLIENTES + " WHERE correo = ?",
                new String[]{correo}
        );

        boolean existe = cursor.getCount() > 0;

        cursor.close();
        return existe;
    }
}
