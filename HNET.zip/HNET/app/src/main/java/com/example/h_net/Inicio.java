package com.example.h_net;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


public class Inicio extends AppCompatActivity {

    // Botones superiores
    Button btnHistorial, btnPerfil, btnCrearSolicitud;

    // Medicamentos
    ImageView imgPregabalina, imgAmoxicilina, imgLidocaina, imgEpinefrina;

    // Categorías
    ImageView imgCardiologia, imgPediatria, imgOncologia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);  // El nombre de tu XML

        btnHistorial = findViewById(R.id.btnHistorial);
        btnPerfil = findViewById(R.id.btnPerfil);
        btnCrearSolicitud = findViewById(R.id.btnCrearSolicitud);

        // Medicamentos
        imgPregabalina = findViewById(R.id.imgPregabalina);
        imgAmoxicilina = findViewById(R.id.imgAmoxicilina);
        imgLidocaina = findViewById(R.id.imgLidocaina);
        imgEpinefrina = findViewById(R.id.imgEpinefrina);

        // Categorías
        imgCardiologia = findViewById(R.id.imgCardiologia);
        imgPediatria = findViewById(R.id.imgPediatria);
        imgOncologia = findViewById(R.id.imgOncologia);


        // ============================
        //       ACCIONES BOTONES
        // ============================

        btnHistorial.setOnClickListener(v -> {
                    Toast.makeText(this, "Abriendo historial...", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Inicio.this, Historial.class);
                    startActivity(intent);
                }
        );

        btnPerfil.setOnClickListener(v -> {
                    Toast.makeText(this, "Abriendo perfil...", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Inicio.this, Perfil.class);
                    startActivity(intent);
                }

        );

        btnCrearSolicitud.setOnClickListener(v -> {
                    Toast.makeText(this, "Creando nueva solicitud...", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Inicio.this, CrearSolicitud.class);
                    startActivity(intent);
                }
        );


        // ============================
        //   CLIC EN MEDICAMENTOS
        // ============================

        imgPregabalina.setOnClickListener(v ->
                Toast.makeText(this, "Pregabalina seleccionada", Toast.LENGTH_SHORT).show()
        );

        imgAmoxicilina.setOnClickListener(v ->
                Toast.makeText(this, "Amoxicilina seleccionada", Toast.LENGTH_SHORT).show()
        );

        imgLidocaina.setOnClickListener(v ->
                Toast.makeText(this, "Lidocaína seleccionada", Toast.LENGTH_SHORT).show()
        );

        imgEpinefrina.setOnClickListener(v ->
                Toast.makeText(this, "Epinefrina seleccionada", Toast.LENGTH_SHORT).show()
        );


        // ============================
        //   CLIC EN CATEGORÍAS
        // ============================

        imgCardiologia.setOnClickListener(v -> {
                    Toast.makeText(this, "Categoría: Cardiología", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Inicio.this, Cardiologia.class);
                    startActivity(intent);
                }
        );

        imgPediatria.setOnClickListener(v -> {
                    Toast.makeText(this, "Categoría: Pediatría", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Inicio.this, Pediatria.class);
                    startActivity(intent);
                }
        );

        imgOncologia.setOnClickListener(v -> {
                    Toast.makeText(this, "Categoría: Oncología", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Inicio.this, Oncologia.class);
                    startActivity(intent);
                }
        );
    }
}
