package com.example.h_net;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DetallesDonaciones extends AppCompatActivity {

    private ImageView imgMedicamento;
    private TextView txtNombre, txtDescripcion, txtCantidad;
    private Button btnSolicitar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_donaciones);

        imgMedicamento = findViewById(R.id.imgMedicamento);
        txtNombre = findViewById(R.id.txtNombre);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        txtCantidad = findViewById(R.id.txtCantidad);
        btnSolicitar = findViewById(R.id.btnSolicitar);

        // Recuperar los datos del intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            txtNombre.setText(extras.getString("nombre"));
            txtDescripcion.setText(extras.getString("descripcion"));
            txtCantidad.setText("Cantidad disponible: " + extras.getString("cantidad"));
            imgMedicamento.setImageResource(extras.getInt("imagen"));
        }

        btnSolicitar.setOnClickListener(v ->
                Toast.makeText(this, "Solicitud enviada para " + txtNombre.getText(), Toast.LENGTH_SHORT).show()
        );
    }
}
