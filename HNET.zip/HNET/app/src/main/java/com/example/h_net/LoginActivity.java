package com.example.h_net;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText editCodigo, editPassword;
    Button btnContinuar, btnRegistro;
    DB db;

    private static final String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        try {
            // Inicializar la base de datos
            db = new DB(this);

            // Vincular vistas
            editCodigo = findViewById(R.id.editCodigo);
            editPassword = findViewById(R.id.editPassword);
            btnContinuar = findViewById(R.id.btnContinuar);
            btnRegistro = findViewById(R.id.btnRegistro);

            setupClickListeners();

        } catch (Exception e) {
            Log.e(TAG, "Error en onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error al inicializar la aplicación", Toast.LENGTH_LONG).show();
        }
    }

    private void setupClickListeners() {
        // Botón "Continuar"
        btnContinuar.setOnClickListener(v -> {
            try {
                String correo = editCodigo.getText().toString().trim();
                String password = editPassword.getText().toString().trim();

                Log.d(TAG, "Intentando login con: " + correo);

                if (correo.isEmpty() || password.isEmpty()) {
                    Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Validar en la base de datos
                boolean valido = db.verificarLogin(correo, password);
                Log.d(TAG, "Resultado verificación: " + valido);

                if (valido) {
                    Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();

                    // Guardar correo en SharedPreferences
                    SharedPreferences prefs = getSharedPreferences("sesion", MODE_PRIVATE);
                    prefs.edit().putString("correo", correo).apply();

                    // Redirigir al inicio
                    Intent intent = new Intent(LoginActivity.this, Inicio.class);
                    startActivity(intent);
                    finish();

                } else {
                    Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error en login: " + e.getMessage(), e);
                Toast.makeText(this, "Error al iniciar sesión: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        // Botón "Registro"
        btnRegistro.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(LoginActivity.this, Registro.class);
                startActivity(intent);
            } catch (Exception e) {
                Log.e(TAG, "Error al ir a registro: " + e.getMessage(), e);
                Toast.makeText(this, "Error al abrir registro", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Cerrar la base de datos si es necesario
    }
}