package com.example.h_net;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;

public class CrearSolicitud extends AppCompatActivity {

    private EditText etNombreMedicamento, etCantidad, etDescripcion;
    private Button btnEnviarSolicitud, btnCancelarSolicitud;
    private DB dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_solucitud);

        // Vincular vistas
        etNombreMedicamento = findViewById(R.id.etNombreMedicamento);
        etCantidad = findViewById(R.id.etCantidad);
        etDescripcion = findViewById(R.id.etDescripcion);
        btnEnviarSolicitud = findViewById(R.id.btnEnviarSolicitud);
        btnCancelarSolicitud = findViewById(R.id.btnCancelarSolicitud);

        // Inicializar DB
        dbHelper = new DB(this);

        // Evento botón Enviar
        btnEnviarSolicitud.setOnClickListener(v -> {
            String nombre = etNombreMedicamento.getText().toString().trim();
            String cantidad = etCantidad.getText().toString().trim();
            String descripcion = etDescripcion.getText().toString().trim();

            if (nombre.isEmpty() || cantidad.isEmpty() || descripcion.isEmpty()) {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            } else {
                // Obtener correo del usuario logueado
                SharedPreferences sharedPreferences = getSharedPreferences("sesion", MODE_PRIVATE);
                String correoUsuario = sharedPreferences.getString("correo", null);

                if (correoUsuario == null) {
                    Toast.makeText(this, "No se encontró usuario logueado", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Guardar solicitud en la base de datos
                boolean exito = guardarSolicitud(nombre, cantidad, descripcion, correoUsuario);
                if (exito) {
                    Toast.makeText(this, "Solicitud enviada correctamente", Toast.LENGTH_LONG).show();
                    // Volver al inicio
                    startActivity(new Intent(this, Inicio.class));
                    finish();
                } else {
                    Toast.makeText(this, "Error al enviar la solicitud", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Evento botón Cancelar
        btnCancelarSolicitud.setOnClickListener(v -> {
            startActivity(new Intent(this, Inicio.class));
            finish();
        });
    }

    /**
     * Guarda la solicitud en la base de datos SQLite
     */
    private boolean guardarSolicitud(String nombre, String cantidad, String descripcion, String correoUsuario) {
        try {
            SQLiteDatabase database = dbHelper.getWritableDatabase();

            ContentValues valores = new ContentValues();
            valores.put("nombreMedicamento", nombre);
            valores.put("cantidad", cantidad);
            valores.put("descripcion", descripcion);
            valores.put("correoUsuario", correoUsuario); // correo del usuario logueado

            long resultado = database.insert(DB.TABLE_SOLICITUDES, null, valores);

            return resultado != -1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}