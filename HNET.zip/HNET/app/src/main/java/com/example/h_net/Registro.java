package com.example.h_net;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {

    private static final String TAG = "RegistroActivity";
    EditText editHospital, editTelefono, editCorreo, editEncargado, editEstado, editMunicipio;
    Button btnEnviarRegistro;
    DB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        try {
            db = new DB(this);
            inicializarVistas();
            configurarBotones();
        } catch (Exception e) {
            Log.e(TAG, "Error en onCreate: " + e.getMessage());
            Toast.makeText(this, "Error al inicializar registro", Toast.LENGTH_LONG).show();
        }
    }

    private void inicializarVistas() {
        editHospital = findViewById(R.id.editHospital);
        editTelefono = findViewById(R.id.editTelefono);
        editCorreo = findViewById(R.id.editCorreo);
        editEncargado = findViewById(R.id.editEncargado);
        editEstado = findViewById(R.id.editEstado);
        editMunicipio = findViewById(R.id.editMunicipio);
        btnEnviarRegistro = findViewById(R.id.btnEnviarRegistro);
    }

    private void configurarBotones() {
        btnEnviarRegistro.setOnClickListener(v -> {
            try {
                registrarUsuario();
            } catch (Exception e) {
                Log.e(TAG, "Error en registro: " + e.getMessage());
                Toast.makeText(this, "Error en registro: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void registrarUsuario() {
        String hospital = editHospital.getText().toString().trim();
        String telefono = editTelefono.getText().toString().trim();
        String correo = editCorreo.getText().toString().trim();
        String encargado = editEncargado.getText().toString().trim();
        String estado = editEstado.getText().toString().trim();
        String municipio = editMunicipio.getText().toString().trim();

        // Validar campos vacíos
        if (hospital.isEmpty() || telefono.isEmpty() || correo.isEmpty() ||
                encargado.isEmpty() || estado.isEmpty() || municipio.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validar formato de correo básico
        if (!correo.contains("@")) {
            Toast.makeText(this, "Por favor, ingresa un correo válido", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar si el correo ya existe
        if (db.existeCorreo(correo)) {
            Toast.makeText(this, "Este correo ya está registrado", Toast.LENGTH_SHORT).show();
            return;
        }

        // Contraseña por defecto
        String contrasenia = "12345";

        // Guardar en la base de datos
        String resultado = db.guardar(hospital, telefono, correo, encargado, estado, municipio, contrasenia);
        Toast.makeText(this, resultado, Toast.LENGTH_SHORT).show();

        if (resultado.contains("correctamente")) {
            Toast.makeText(this, "Tu contraseña asignada es: 12345", Toast.LENGTH_LONG).show();
            finish(); // Regresa al login
        }
    }
}