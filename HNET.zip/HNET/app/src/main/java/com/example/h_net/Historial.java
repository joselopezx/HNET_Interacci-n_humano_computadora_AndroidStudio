package com.example.h_net;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class Historial extends AppCompatActivity {

    private ListView listViewHistorial;
    private Button btnRegresarInicio;
    private DB dbHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        listViewHistorial = findViewById(R.id.listViewHistorial);
        btnRegresarInicio = findViewById(R.id.btnRegresarInicio);

        dbHelper = new DB(this);
        sharedPreferences = getSharedPreferences("sesion", Context.MODE_PRIVATE);

        String correoUsuario = sharedPreferences.getString("correo", null);

        if (correoUsuario != null) {
            mostrarSolicitudesUsuario(correoUsuario);
        } else {
            Toast.makeText(this, "No hay usuario logueado", Toast.LENGTH_SHORT).show();
        }

        btnRegresarInicio.setOnClickListener(v -> {
            startActivity(new Intent(this, Inicio.class));
            finish();
        });
    }

    private void mostrarSolicitudesUsuario(String correoUsuario) {
        ArrayList<String> solicitudes = new ArrayList<>();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT nombreMedicamento, cantidad, descripcion, fechaSolicitud FROM " + DB.TABLE_SOLICITUDES +
                        " WHERE correoUsuario = ? ORDER BY fechaSolicitud DESC",
                new String[]{correoUsuario}
        );

        if (cursor.moveToFirst()) {
            do {
                String nombre = cursor.getString(0);
                String cantidad = cursor.getString(1);
                String descripcion = cursor.getString(2);
                String fecha = cursor.getString(3);

                String item = nombre + " - " + cantidad + " unidades\nFecha: " + fecha + "\nDetalle: " + descripcion;
                solicitudes.add(item);

            } while (cursor.moveToNext());
        } else {
            solicitudes.add("No tienes solicitudes registradas.");
        }

        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                solicitudes
        );
        listViewHistorial.setAdapter(adapter);

        listViewHistorial.setOnItemClickListener((parent, view, position, id) -> {
            String itemSeleccionado = solicitudes.get(position);
            Toast.makeText(this, "Seleccionaste:\n" + itemSeleccionado, Toast.LENGTH_SHORT).show();
        });
    }
}