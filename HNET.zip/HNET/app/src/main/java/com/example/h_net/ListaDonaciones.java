package com.example.h_net;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ListaDonaciones extends AppCompatActivity {

    private Button btnVerDetalles1, btnVerDetalles2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_donaciones);

        btnVerDetalles1 = findViewById(R.id.btnVerDetalles1);
        btnVerDetalles2 = findViewById(R.id.btnVerDetalles2);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaDonaciones.this, DetallesDonaciones.class);

                // Pasar datos básicos del medicamento seleccionado
                if (v.getId() == R.id.btnVerDetalles1) {
                    intent.putExtra("nombre", "Amoxicilina 500mg");
                    intent.putExtra("cantidad", "10");
                    intent.putExtra("descripcion", "Antibiótico para infecciones bacterianas comunes.");
                    intent.putExtra("imagen", R.drawable.amoxicilina);
                } else if (v.getId() == R.id.btnVerDetalles2) {
                    intent.putExtra("nombre", "Pregabalina 75mg");
                    intent.putExtra("cantidad", "15");
                    intent.putExtra("descripcion", "Usado para el tratamiento del dolor neuropático.");
                    intent.putExtra("imagen", R.drawable.pregabalina);
                }

                startActivity(intent);
            }
        };
        btnVerDetalles1.setOnClickListener(listener);
        btnVerDetalles2.setOnClickListener(listener);
    }
}
